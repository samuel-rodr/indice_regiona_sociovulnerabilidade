
# PACOTES -----------------------------------------------------------------

library(tidyverse) # Para manipular o banco de dados
library(here) # Para ajudar a gente a organizar o diretório
library(questionr) # Para manipular o banco de dados
library(haven) # Para ler o banco de dados em stata
library(sandwich) # Para o teste t
library(lmtest) # Para o test t

# BANCO DE DADOS ----------------------------------------------------------

bd <- read_stata(here("ReplicationData2.dta"))


# DICIONÁRIO DE VARIÁVEIS -------------------------------------------------

#enroll_count - matrículas
#gender - Gênero
#asian - Alunos asiáticos
#black - Alunos pretos
#hawaiian - Alunos havaianos
#hispanic - Alunos Latinos hispânicos
#white - Alunos brancos
#unknown - Sem classificação
#format_ol - Formato online
#format_blended - Formato misto
#falsexam - Nota no exame final

# O banco segue a classificação de raça nos Estados Unidos, que é feita com base na autodeclaração do indivíduo. As categorias de raça incluem: 
# Branco
# Negro ou afro-americano
# Hispânico ou Latino
# Índio americano ou nativo do Alasca
# Asiático
# Nativo havaiano ou de outra ilha do Pacífico
# Alguma outra raça

# Vale ressaltar que a classificação de raça nos Estados Unidos tem sido considerada problemática, arbitrária e estereotipada. 
# Por isso, vem sendo discutida a necessidade do governo federal de mudar a forma como categoriza as pessoas por raça e etnia.


# PREPARANDO O BANCO ------------------------------------------------------

# O conjunto de dados baixado é mais completo do que o conjunto de dados usado por Facure (2022) 
# Ele considera apenas concluintes (ou seja, vamos pegar a variável enroll_count que descreve a contagem de matrículas que for igual a 3).

bd <- bd %>% filter(enroll_count == 3)

# O conjunto de dados baixado é mais completo do que o conjunto de dados usado por Facure (2022) 
# Ele considera apenas um subconjunto de colunas. Vamos, então, selecionar estas colunas
bd <- bd %>% select(gender, asian, black, hawaiian, hispanic, unknown, white, format_ol, format_blended, falsexam)

# Vamos criar a variável formato_classe que separa os tipos que existiam nesta classe
bd <- bd %>%
  mutate(formato_classe = case_when(
    format_ol %in% 1 ~ "online",
    format_blended %in% 1 ~ "misto",
    TRUE ~ "presencial"
  )) 

# Agora, vamos fazer a média das notas por formato da classe
data <- bd %>%
  group_by(formato_classe) %>%
  summarise(across(everything(), mean, na.rm = TRUE))

#Vamos ver o resultado:
data

# Contar as unidades (pessoas) por grupo de tratamento (isso não é apresentado por Facure, 2022).
a <- sum(as.integer(bd$format_ol))
cat("O número de observações para o formato online:", a, "(", round((a/nrow(bd))*100, 1), "%)")

b <- sum(as.integer(bd$format_blended))
cat("O número de observações para o formato misto:", b, "(", round((b/nrow(bd))*100, 1), "%)")

c <- nrow(bd) - a - b
cat("O número de observações para o formato presencial:", c, "(", round((c/nrow(bd))*100, 1), "%)")


# REGRESSÃO ---------------------------------------------------------------

# Fazendo a regressão linear
modelo <- lm(falsexam ~ format_blended + format_ol, data = bd)

# Resumo do modelo
summary(modelo)


# TESTE T -----------------------------------------------------------------
# Isto é equivalente a um teste t de diferença em médias (assumindo que a variância populacional é desigual entre os grupos de tratamento)
# Nota: pode haver pequenas diferenças nos valores de p obtidos através do teste t e da regressão

# Obtendo os erros robustos com a matriz de variância-covariância HC1
robustos <- vcovHC(modelo, type = "HC1")

# Exibindo o resumo do modelo com erros robustos
coeftest(modelo, vcov = robustos)
